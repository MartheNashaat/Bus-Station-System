
public class Vehicle {
	public String bus;
	public String car;
	public String limosine;
	
	

}
