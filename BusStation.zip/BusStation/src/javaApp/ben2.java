package javaApp;

public class ben2 {
String trip1;
String trip2;
public ben2(String trip12) {
	// TODO Auto-generated constructor stub
}
public String getTrip1() {
	return trip1;
}
public void setTrip1(String trip1) {
	this.trip1 = trip1;
}
public String getTrip2() {
	return trip2;
}
public void setTrip2(String trip2) {
	this.trip2 = trip2;
}

}
