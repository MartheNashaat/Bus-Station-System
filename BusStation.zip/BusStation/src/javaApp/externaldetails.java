package javaApp;

public class externaldetails {

	String tripdest2 ;
	String eprice;
	
	public String getEprice() {
		return eprice;
	}

	public void setEprice(String eprice) {
		this.eprice = eprice;
	}

	public externaldetails( String tripdest2) {
		// TODO Auto-generated constructor stub
	}

	public String getTripdest2() {
		return tripdest2;
	}
	public void setTripdest2(String tripdest2) {
		this.tripdest2 = tripdest2;
	}
	
}
