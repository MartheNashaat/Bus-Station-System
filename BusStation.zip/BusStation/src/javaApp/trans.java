package javaApp;

public class trans {
String transport;

public trans(String transport2) {
	// TODO Auto-generated constructor stub
}

public String getTransport() {
	return transport;
}

public void setTransport(String transport) {
	this.transport = transport;
}


}
