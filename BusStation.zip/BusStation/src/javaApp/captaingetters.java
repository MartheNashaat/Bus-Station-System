package javaApp;

public class captaingetters {
 String capusername;
 String cappassword;
public captaingetters(String capusername2, String cappassword2) {
	// TODO Auto-generated constructor stub
}
public String getCapusername() {
	return capusername;
}
public void setCapusername(String capusername) {
	this.capusername = capusername;
}
public String getCappassword() {
	return cappassword;
}
public void setCappassword(String cappassword) {
	this.cappassword = cappassword;
}
 
	
	
}
