package javaApp;

public class trip {

	String tripdestt;
	String price;

	

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public trip(String tripdestt) {
		// TODO Auto-generated constructor stub
	}

	
	public String getTripdestt() {
		return tripdestt;
	}

	public void setTripdestt(String tripdestt) {
		this.tripdestt = tripdestt;
	}
	

	
	

}
